import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import { TextField, Button } from '@material-ui/core';
import httpService from '../../../API/HttpService/httpService';
import { API_PATH } from './../../../Constants/config';
import MoneyInput from './../../../Components/Forms/MoneyInput';
import { Autocomplete } from '@material-ui/lab';
import { checkValidity } from './../../../Shared/index';
import NumberFormatCustom from './../../../Components/Forms/NumericInput';
import MaskInput from './../../../Components/Forms/MaskInput';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    datePicker:
    {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: 200,
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

export default function EmployementDetail() {
    const [billingStatus, setBillingStatus] = useState([]);
    const [taxType, setTaxType] = useState([]);
    const [workAuthorization, setWorkAuthorization] = useState([]);
    const [designations, setDesignations] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [wageCycle, setWageCycle] = useState([]);
    const [projects, setProjects] = useState([]);
    const [vendors, setVendors] = useState([]);
    const classes = useStyles();
    const [stateObj, setError] = useState({
        error: {

            designation: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            vendor: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            project: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            }, department: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            reportingTo: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            taxTerms: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            workAuth: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            }, billingStatus: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            wageCycle: {
                errorObject: { required: true, isValid: true, errorMessage: "", isDropdown: true }
            },
            phoneNumber: {
                errorObject: { required: true, isValid: true, isNumeric: true, errorMessage: "" }
            },
            dob: {
                errorObject: { required: true, isValid: true, isDate: true, errorMessage: "" }
            },
            wageRate: {
                errorObject: { required: true, isValid: true, isNumeric: true, errorMessage: "" }
            }
        },
        account: {
            designation: null, project: null, phoneNumber: "", dob: new Date(),
            vendor: null, department: null, reportingTo: null, taxTerms: null,
            workAuth: null, billingStatus: null, wageCycle: null, wageRate: ""
        }
    });
    useEffect(() => {
        httpService.all([
            httpService.get(API_PATH.GET_BILLING_STATUS),
            httpService.get(API_PATH.GET_TAX_TYPE),
            httpService.get(API_PATH.GET_WORK_AUTHORIZATION),
            httpService.get(API_PATH.GET_DESIGNATION),
            httpService.get(API_PATH.GET_DEPARTMENTS),
            httpService.get(API_PATH.GET_WAGE_CYCLE),
        ]).then(responses => {
            const [billingStatus, taxType, workAuthorization, designations, departments, wageCycle] = responses;
            setBillingStatus(billingStatus.data);
            setTaxType(taxType.data);
            setWorkAuthorization(workAuthorization.data);
            setDesignations(designations.data);
            setDepartments(departments.data);
            setWageCycle(wageCycle.data);
            setProjects(designations.data);
            setVendors(designations.data)
        });
    }, []);
    const changeHandler = (e) => {
        const { value, name } = e.target;
        const { error, account } = stateObj;
        const validationObj = error[name];

        const { errorObject } = checkValidity(value, name, validationObj);
        console.log(errorObject);
        setError({ ...stateObj, error: { ...error, [name]: { errorObject } }, account: { ...account, [name]: value } });

    }
    const onDropdownChangeHandler = (cntrlName, value) => {
        const { error, account } = stateObj;
        const validationObj = error[cntrlName];
        const id = value === null ? 0 : value.id;

        const { errorObject } = checkValidity(id, cntrlName, validationObj);
        if (cntrlName === 'country') {
            getStates(id);
        }
        else if (cntrlName === 'state') {
            getCities(id);
        }

        setError({ ...stateObj, error: { ...error, [cntrlName]: { errorObject } }, account: { ...account, [cntrlName]: value } });

    }
    const onDatePickerChanged = (cntrlName, value) => {

        const { error, account } = stateObj;
        const validationObj = error[cntrlName];
        console.log(cntrlName, value, validationObj);
        const { errorObject } = checkValidity(value, cntrlName, validationObj);
        setError({ ...stateObj, error: { ...error, [cntrlName]: { errorObject } }, account: { ...account, [cntrlName]: value } });

    }
    const onSubmitHandler = () => {
        const { error, account } = stateObj;
        let result = true;
        for (let err in error) {
            const value = account[err];
            const name = err;

            const validationObj = error[name];

            const { errorObject } = checkValidity(value, name, validationObj);
            console.log(validationObj, value);
            if (errorObject.errorMessage.trim() !== "") {
                result = false;
            }

            error[name] = { errorObject };
        }

        setError({ account, error: error })
        if (result === true) {

        }
    }
    return (
        <Grid container spacing={2}>
            <Grid item xs={3}>
                <TextField
                    variant="outlined"
                    margin="normal"
                    fullWidth
                    id="employeeId"
                    label="Employee Id"
                    name="employeeId"
                    autoComplete="employeeId"
                    InputLabelProps={{
                        shrink: true,
                    }}
                    inputProps={{
                        maxLength: 12,
                    }}
                    autoFocus
                />

            </Grid>
            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.designation}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("designation", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.designation_name
                    }}
                    id="ddlDesination"
                    options={designations}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.designation.errorObject.isValid}
                            helperText={stateObj.error.designation.errorObject.errorMessage} name="country" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Designation" variant="outlined" />)
                    }}
                />
            </Grid>
            <Grid item xs={3}>

                <Autocomplete
                    value={stateObj.account.vendor}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("vendor", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.designation_name
                    }}
                    id="controllable-states-demo"
                    name="vendor"
                    options={vendors}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.vendor.errorObject.isValid}
                            helperText={stateObj.error.vendor.errorObject.errorMessage} name="country" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Vendor" variant="outlined" />)
                    }}
                />
            </Grid>

            <Grid item xs={3}>

                <Autocomplete
                    value={stateObj.account.project}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("project", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.designation_name
                    }}
                    id="controllable-states-demo"
                    name="country"
                    options={projects}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.project.errorObject.isValid}
                            helperText={stateObj.error.project.errorObject.errorMessage} name="country" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Project" variant="outlined" />)
                    }}
                />
            </Grid>

            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.department}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("department", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.department
                    }}
                    id="controllable-states-demo"
                    name="department"
                    options={departments}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.department.errorObject.isValid}
                            helperText={stateObj.error.department.errorObject.errorMessage} name="country" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Department" variant="outlined" />)
                    }}
                />

            </Grid>
            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.reportingTo}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("reportingTo", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.department
                    }}
                    id="controllable-states-demo"
                    name="reportingTo"
                    options={departments}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.reportingTo.errorObject.isValid}
                            helperText={stateObj.error.reportingTo.errorObject.errorMessage} name="reportingTo" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Reporting To" variant="outlined" />)
                    }}
                />
            </Grid>
            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.taxTerms}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("taxTerms", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.tax_type
                    }}
                    id="controllable-states-demo"
                    name="taxTerms"
                    options={taxType}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.taxTerms.errorObject.isValid}
                            helperText={stateObj.error.taxTerms.errorObject.errorMessage} name="taxTerms" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Tax Terms" variant="outlined" />)
                    }}
                />
            </Grid>


            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.workAuth}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("workAuth", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.work_auth_type
                    }}
                    id="controllable-states-demo"
                    name="workAuth"
                    options={workAuthorization}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.workAuth.errorObject.isValid}
                            helperText={stateObj.error.workAuth.errorObject.errorMessage} name="country" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Work Authorization" variant="outlined" />)
                    }}
                />
            </Grid>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <Grid item xs={3}>

                    <KeyboardDatePicker
                        margin="normal"
                        inputVariant="outlined"
                        fullWidth
                        disableFuture

                        id="date-picker-dialog"
                        label="Employment Start Date"
                        format="MM/dd/yyyy"
                        value={stateObj.account.dob}
                        onChange={(event, newValue) => {
                            onDatePickerChanged("dob", newValue);
                        }}
                        error={!stateObj.error.dob.errorObject.isValid}
                        helperText={stateObj.error.dob.errorObject.errorMessage}
                        KeyboardButtonProps={{
                            "aria-label": "change date"
                        }}
                    />
                </Grid>
            </MuiPickersUtilsProvider>

            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.billingStatus}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("billingStatus", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.status
                    }}
                    id="controllable-states-demo"
                    name="billingStatus"
                    options={billingStatus}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.billingStatus.errorObject.isValid}
                            helperText={stateObj.error.billingStatus.errorObject.errorMessage} name="billingStatus" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Billing Status" variant="outlined" />)
                    }}
                />
            </Grid>
            <Grid item xs={3}>
                <TextField
                    variant="outlined"
                    margin="normal"
                    fullWidth
                    id="wageRate"
                    label="Wage Rate"
                    name="wageRate"
                    InputLabelProps={{
                        shrink: true,
                    }}
                    InputProps={{
                        inputComponent: MoneyInput,
                    }}
                    inputProps={{
                        maxLength: 8,
                    }}

                    onChange={changeHandler}
                />

            </Grid>

            <Grid item xs={3}>
                <Autocomplete
                    value={stateObj.account.wageCycle}

                    onChange={(event, newValue) => {
                        onDropdownChangeHandler("wageCycle", newValue);
                    }}
                    getOptionLabel={(option) => {
                        return option.time_cycle
                    }}
                    id="controllable-states-demo"
                    name="wageCycle"
                    options={wageCycle}
                    margin="normal"
                    fullWidth
                    renderInput={(params) => {
                        return (<TextField  {...params} error={!stateObj.error.wageCycle.errorObject.isValid}
                            helperText={stateObj.error.wageCycle.errorObject.errorMessage} name="wageCycle" margin="normal" inputProps={{
                                ...params.inputProps,
                                autoComplete: 'new-password', // disable autocomplete and autofill
                            }} fullWidth InputLabelProps={{
                                shrink: true,
                            }} label="Select Wage Cycle" variant="outlined" />)
                    }}
                />
            </Grid>
            <Grid item xs={3}>

            </Grid>


            <Grid item xs={12} style={{ textAlign: "center" }}>
                <Button
                    type="submit"

                    variant="contained"
                    color="primary"
                    className={classes.submit}
                    onClick={onSubmitHandler}

                >
                    Next
</Button>

                <Button
                    type="submit"

                    variant="contained"
                    color="primary"
                    className={classes.submit}
                    onClick={onSubmitHandler}

                >
                    Reset
</Button>



            </Grid>


        </Grid>

    );
}