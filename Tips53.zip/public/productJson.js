export function productJson() {
    return {
        "id": "shop/new/all-new",
        "name": "All New",
        "categoryType": "subcat",
        'mylist': [
            {
                'title': 'Futurama',
                'id': 1,
                'img': 'http://cdn1.nflximg.net/webp/7621/3787621.webp'
            },
            {
                'title': 'The Interview',
                'id': 2,
                'img': 'http://cdn1.nflximg.net/webp/1381/11971381.webp'
            },
            {
                'title': 'Gilmore Girls',
                'id': 3,
                'img': 'http://cdn1.nflximg.net/webp/7451/11317451.webp'
            }
        ],
        'recommendations': [
            {



                'title': 'Family Guy',



                'id': 4,



                'img': 'http://cdn5.nflximg.net/webp/5815/2515815.webp'



            },



            {



                'title': 'The Croods',



                'id': 5,



                'img': 'http://cdn3.nflximg.net/webp/2353/3862353.webp'



            },



            {



                'title': 'Friends',



                'id': 6,



                'img': 'http://cdn0.nflximg.net/webp/3200/9163200.webp'



            }



        ],
        "groups": [
            {
                "id": "belgian-linen-embroidery-duvet-cover-shams-slate-white-b3024",
                "name": "Belgian Linen Ladder Stripe Embroidery Duvet Cover &amp; Shams - Slate/White",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-embroidery-duvet-cover-shams-slate-white-b3024/"
                },
                "priceRange": {
                    "regular": {
                        "high": 329,
                        "low": 44
                    },
                    "selling": {
                        "high": 263.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-s-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-s-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-6-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0012/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-embroidery-duvet-cover-shams-slate-white-b3024",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-embroidery-duvet-cover-shams-white-flax-b3025",
                "name": "Belgian Linen Ladder Stripe Embroidery Duvet Cover &amp; Shams - White/Flax",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-embroidery-duvet-cover-shams-white-flax-b3025/"
                },
                "priceRange": {
                    "regular": {
                        "high": 329,
                        "low": 44
                    },
                    "selling": {
                        "high": 263.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-8-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0006/img2m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-5-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-9-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-embroidery-duvet-cover-shams-white-flax-b3025",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-embroidery-duvet-cover-shams-white-midnight-b3026",
                "name": "Belgian Linen Ladder Stripe Embroidery Duvet Cover &amp; Shams - White/Midnight",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-embroidery-duvet-cover-shams-white-midnight-b3026/"
                },
                "priceRange": {
                    "regular": {
                        "high": 340,
                        "low": 44
                    },
                    "selling": {
                        "high": 263.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-2-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-9-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-embroidery-duvet-cover-shams-white-midnight-b3026",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-embroidery-duvet-shams-white-horseradish-b3027",
                "name": "Belgian Linen Ladder Stripe Embroidery Duvet Cover &amp; Shams - White/Dark Horseradish",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-embroidery-duvet-shams-white-horseradish-b3027/"
                },
                "priceRange": {
                    "regular": {
                        "high": 329,
                        "low": 44
                    },
                    "selling": {
                        "high": 263.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0009/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0009/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0006/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-5-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-embroidery-duvet-shams-white-horseradish-b3027",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-ladder-stripe-embroidery-sheet-set-b3028",
                "name": "Belgian Linen Ladder Stripe Embroidery Sheet Set",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-ladder-stripe-embroidery-sheet-set-b3028/"
                },
                "priceRange": {
                    "regular": {
                        "high": 349,
                        "low": 269
                    },
                    "selling": {
                        "high": 279.2,
                        "low": 215.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0010/belgian-linen-ladder-stripe-embroidery-sheet-set-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0010/belgian-linen-ladder-stripe-embroidery-sheet-set-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0013/belgian-linen-ladder-stripe-embroidery-sheet-set-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-sheet-set-m.jpg",
                        "height": 363
                    },
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-sheet-set-2-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-ladder-stripe-embroidery-sheet-set-b3028",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-merrow-edge-duvet-shams-white-misty-rose-b3036",
                "name": "Belgian Linen Merrow Edge Duvet Cover &amp; Shams - White/Misty Rose",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-merrow-edge-duvet-shams-white-misty-rose-b3036/"
                },
                "priceRange": {
                    "regular": {
                        "high": 299,
                        "low": 44
                    },
                    "selling": {
                        "high": 239.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202005/0006/belgian-linen-merrow-edge-duvet-cover-shams-white-misty-ro-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202005/0006/belgian-linen-merrow-edge-duvet-cover-shams-white-misty-ro-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-7-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-merrow-edge-duvet-shams-white-misty-rose-b3036",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-merrow-edge-duvet-shams-white-iron-gate-b3035",
                "name": "Belgian Linen Merrow Edge Duvet Cover &amp; Shams - White/Iron Gate",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-merrow-edge-duvet-shams-white-iron-gate-b3035/"
                },
                "priceRange": {
                    "regular": {
                        "high": 299,
                        "low": 44
                    },
                    "selling": {
                        "high": 239.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0013/belgian-linen-merrow-edge-duvet-cover-shams-white-iron-gat-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0013/belgian-linen-merrow-edge-duvet-cover-shams-white-iron-gat-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0013/belgian-linen-merrow-edge-duvet-cover-shams-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-merrow-edge-duvet-shams-white-iron-gate-b3035",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-merrow-duvet-shams-white-dark-horseradish-b3034",
                "name": "Belgian Linen Merrow Edge Duvet Cover &amp; Shams - White/Dark Horseradish",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-merrow-duvet-shams-white-dark-horseradish-b3034/"
                },
                "priceRange": {
                    "regular": {
                        "high": 299,
                        "low": 44
                    },
                    "selling": {
                        "high": 239.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-6-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-6-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-ladder-stripe-embroidery-duvet-cover-shams-w-3-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-merrow-duvet-shams-white-dark-horseradish-b3034",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-merrow-edge-duvet-cover-shams-flax-midnight-b3033",
                "name": "Belgian Linen Merrow Edge Duvet Cover &amp; Shams - Flax/Midnight",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-merrow-edge-duvet-cover-shams-flax-midnight-b3033/"
                },
                "priceRange": {
                    "regular": {
                        "high": 299,
                        "low": 44
                    },
                    "selling": {
                        "high": 239.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-1-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-1-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-flax-midnight-1-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-merrow-edge-duvet-cover-shams-flax-midnight-b3033",
                    "type": "GROUP_REVIEWS"
                }
            },
            {
                "id": "belgian-linen-merrow-duvet-cover-shams-flax-terracotta-b3032",
                "name": "Belgian Linen Merrow Edge Duvet Cover &amp; Shams - Flax/Terracotta",
                "links": {
                    "www": "https://www.westelm.com/products/belgian-linen-merrow-duvet-cover-shams-flax-terracotta-b3032/"
                },
                "priceRange": {
                    "regular": {
                        "high": 299,
                        "low": 44
                    },
                    "selling": {
                        "high": 239.2,
                        "low": 35.2
                    },
                    "type": "special"
                },
                "thumbnail": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "thumbnail",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-flax-terracott-2-m.jpg",
                    "height": 363
                },
                "hero": {
                    "size": "m",
                    "meta": "",
                    "alt": "",
                    "rel": "hero",
                    "width": 363,
                    "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-flax-terracott-2-m.jpg",
                    "height": 363
                },
                "images": [
                    {
                        "size": "m",
                        "meta": "",
                        "alt": "",
                        "rel": "althero",
                        "width": 363,
                        "href": "https://www.westelm.com/weimgs/rk/images/wcm/products/202003/0005/belgian-linen-merrow-edge-duvet-cover-shams-flax-terracott-3-m.jpg",
                        "height": 363
                    }
                ],
                "swatches": [],
                "messages": [],
                "flags": [
                    {
                        "bopisSuppress": false,
                        "rank": 3,
                        "id": "newcore"
                    },
                    {
                        "bopisSuppress": false,
                        "rank": 9,
                        "id": "fairTrade"
                    }
                ],
                "reviews": {
                    "recommendationCount": 0,
                    "likelihood": 0,
                    "reviewCount": 0,
                    "averageRating": 0,
                    "id": "belgian-linen-merrow-duvet-cover-shams-flax-terracotta-b3032",
                    "type": "GROUP_REVIEWS"
                }
            }
        ],
        "totalPages": 83,
        "categories": []
    }


}
export function renderCityName(state, val) {
    return (
        state.title.toLowerCase().indexOf(val.toLowerCase()) !== -1
    );
}